
<p align='center'><img src="https://i.ibb.co/0Vj3VTw/download-1.png" width="120" ></p>



<h4 align='center'>📺 The PHP Script For Grab Streaming Links and Play it ,</br> This  Works Mobile,Tizen OS ,Web Os, AndroidTV , PC Browser Perfect

Through  Hosting or LocalHost  </br></br>🌟 Star This Repository Before Forking 😎</br>Don't Edit This Script



<h2>🍁 HOW TO USE : </h2>

### 🔐 Installation :

### 🅰️ First Download This Application ( PHP WEB SERVER )

1. `KSWEB PRO v3.987 for Mobile`

```

https://tsneh.vercel.app/ksweb_3.987.apk

```

2. `XAMPP for Windows (PC)`

```

https://www.apachefriends.org/download.html

```

### 🅱️ Then Download This Zip File

- [STALKER-PORTAL. Zip](https://github.com/Jitendraunatti/STALKER-PORTAL/archive/refs/heads/main.zip) </br>

1. Locate & Extract all Files in LocalHost `Htdocs` Root Folder. </br>

2. Open KSWEB app & start the server. </br>

3. Now Open `STALKER-PORTAL` Below Link :

```

http://localhost:8080/STALKER-PORTAL/

```

4. First Login with your credentials.




</br>


<h3>TIZEN OS ,WEB OS  ANDRIOD TV SETUP:</h3>


-   **Install KS Web App**:
    
    -   Ensure that the **KS Web** app is installed on your mobile device.
-   **Connect Devices**:
    
    -   Your mobile device and TV must be connected to the **same Wi-Fi network**.
-   **Accessing on TV**:
    
    -   Open the web browser on your TV.
    -   On your mobile device, you will be provided with an IP address by the KS Web app.
    -   **Note**: This IP address is different for every user.
    -   Enter the provided IP address into your TV's browser .Ex http://192.168.0.120:8080
-   **Example**:
<img src="https://i.ibb.co/K5s5n5d/IMG-20240811-170717.jpg" alt="mob-Catchup" width="320">



<h3>👿 LOGIN :</h3>

1. Open `STALKER-PORTAL`  </br>

2. Click on the Login button. </br>
3. Enter your **Stalker portal detail**. </br>
<img src="https://i.ibb.co/MCVZkYY/image.png" alt="home" width="700" height="350">

<h3>♻️ JOIN FOR UPDATES :</h3>

- JOIN OUR TELEGRAM CHANNEL

- https://t.me/jitendraunatti_github

</br>
<h3>☠️ ADVANCED  FEATURES :</h3>

- **Token Sharing**
- **permanent token generator**
- The **previous dump playlist** is stored under the data folder, or you can access it from the index.php page
- Supports all types of **stalker portals** if they are working at the current location as well as in **OTT Navigator**

<h3>❤️‍🔥TOKEN 𝐒𝐇𝐀𝐑𝐈𝐍𝐆 𝐅𝐄𝐀𝐓𝐔𝐑𝐄𝐒.  :</h3>
<img src="https://i.ibb.co/QMJNWwz/image.png" alt="home" width="700" height="350">

- BY DEFAULT, TOKEN SHARING MODE IS OFF. YOU NEED TO TURN IT ON IF YOU WANT TO USE IT

<h3>😇 SCRIPT FEATURES :</h3>

- Token Sharing
- The previous dump playlist is stored under the data folder, or you can access it from  the index.php page
- permanent token generator

- Auto playlist fetcher

- New UI & Design

- Web Play 
-  Works on **Mobile,Tizen OS ,Web Os, AndroidTV , PC Browser Perfect**

<h3>💖 PLAYER FEATURES :</h3>

- Search Feature Added</br>

1. 🔍 SEARCH BY CHANNEL NAME

```

e.g. Sony,Zee,Star ...

```

2. 🔍 SEARCH BY GENRE

```

e.g. Entertainment,Kids,Movies,Music ...

```

3. 🔍 SEARCH BY LANGUAGE

```

e.g. Hindi,Tamil,Kannada,Odia ...

```



</br>




## ▶️ PlayList Methods :

• In Tivimate or OTT Navigator Player Put Links Format Like Below :

```

http://localhost:8080/STALKER-PORTAL/playlist.php

```

• Hurrah !! Now Play & Enjoy with your STALKER-PORTAL Channels .

<h3>🚸 WARNINGS :</h3>

- This is Just For Educational Purpose
- I am in no way responsible if you misuse the code and cause revenue loss to the concerned parties and owners of the portal
- Don't Sell this Script, This is 💯% Free
<hr>

<h3>🤗 CONTACT US : </h3>

- TELEGRAM CHANNEL  JOIN NOW https://t.me/jitendraunatti_github
- FOR ANY QUERY CONTACT US ON [PROTON-MAIL](mailto:jitendraunatti@pm.me)

</br>
<hr>

<h3> ⚠️License and Disclosures : </hr>

This code is just a CASE STUDY on how the authentication mechanism and live streaming using IPTV works I am in no way responsible if you misuse the code and cause revenue loss to the concerned parties and owners of the portal
This code is protected under the [GPL](https://github.com/Jitendraunatti/STALKER-PORTAL/blob/main/LICENSE) license


<h4 align='center'>© 2021-24 JITENDRA KUMAR</h4>

<!-- DO NOT REMOVE THIS CREDIT -->
<!-- © 2021-24 jitendra kumar -->
