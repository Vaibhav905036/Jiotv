<?php
$playlist_file = "playlist.m3u";

// Check if the playlist file exists
if (!file_exists($playlist_file)) {
    die('The playlist is empty or the file was not found.');
}

$playlist_content = file_get_contents($playlist_file);

if ($playlist_content === false) {
    die('Error reading playlist file.');
}

$modified_content = preg_replace('/^\s*[\r\n]+/m', '', $playlist_content);

$allowed_groups = @file('app/data/filter.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

if ($allowed_groups === false) {  
    header('Content-Type: audio/mpegurl');
    header('Content-Disposition: attachment; filename="playlist.m3u"');
    echo $playlist_content;
    exit;
}

if (empty($allowed_groups)) {
    header('Content-Type: audio/mpegurl');
    header('Content-Disposition: attachment; filename="playlist.m3u"');
    echo $playlist_content;
    exit;
}

$filtered_content = '';
$lines = explode("\n", $modified_content);
$include_entry = false;
$group_found = false;

foreach ($lines as $line) {

    if (strpos($line, '#EXTINF') !== false) {
        $include_entry = false; 
        
        foreach ($allowed_groups as $group) {
            if (strpos($line, 'group-title="' . $group . '"') !== false) {
                $include_entry = true;
                $group_found = true;
                break;
            }
        }
    }
    
    if ($include_entry || trim($line) === '') {
        $filtered_content .= $line . "\n";
    }
}

if (!$group_found) {
    
    header('Content-Type: audio/mpegurl');
    header('Content-Disposition: attachment; filename="playlist.m3u"');
    echo $playlist_content;
    exit;
}

$final_content = "#EXTM3U\n" . $filtered_content;

header('Content-Type: audio/mpegurl');
header('Content-Disposition: attachment; filename="playlist.m3u"');

echo $final_content;
?>
