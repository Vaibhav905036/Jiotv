<?php
function getGroupsFromM3U($file) {
    $groups = [];
    if (!file_exists($file) || filesize($file) == 0) {
        return $groups; // Return empty if file is missing or empty
    }

    $lines = file($file, FILE_IGNORE_NEW_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '#EXTINF') !== false) {
            preg_match('/group-title="([^"]+)"/', $line, $matches);
            if (isset($matches[1])) {
                $group = trim($matches[1]);
                if (!in_array($group, $groups)) {
                    $groups[] = $group;
                }
            }
        }
    }
    return $groups;
}

function getSavedFilters($file) {
    if (file_exists($file)) {
        $filters = file($file, FILE_IGNORE_NEW_LINES);
        return $filters;
    }
    return [];
}

$m3uFile = 'playlist.m3u';
$filterFile = 'app/data/filter.txt';

$groups = getGroupsFromM3U($m3uFile);
$savedFilters = getSavedFilters($filterFile);

if (isset($_POST['save']) && isset($_POST['groups'])) {    
    $selectedGroups = $_POST['groups'];
    file_put_contents($filterFile, implode("\n", $selectedGroups));
    $savedFilters = $selectedGroups; 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group Filter</title>
</head>
<body>

    <h1>Select Groups</h1>

    <?php if (empty($groups)): ?>
        <p>The playlist is empty or the file was not found.</p>
    <?php else: ?>
        <form method="POST" action="filter.php">
            <?php foreach ($groups as $group): ?>
                <div>
                    <input type="checkbox" name="groups[]" value="<?php echo $group; ?>" 
                    <?php echo in_array($group, $savedFilters) ? 'checked' : ''; ?>>
                    <label><?php echo $group; ?></label>
                </div>
            <?php endforeach; ?>

            <br>
            <button type="submit" name="save" value="1">Save</button>
        </form>
    <?php endif; ?>

</body>
</html>
